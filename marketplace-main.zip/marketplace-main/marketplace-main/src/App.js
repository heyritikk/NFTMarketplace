import "./App.css";
import NFTMarketplace from "./Marketplace";

function App() {
  return (
    <div>
      <NFTMarketplace />
    </div>
  );
}
//0x5FbDB2315678afecb367f032d93F642f64180aa3

export default App;
