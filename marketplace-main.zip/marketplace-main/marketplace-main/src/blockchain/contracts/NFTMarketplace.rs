#![cfg_attr(not(feature = "std"), no_std)]

use ink::prelude::string::String;
use ink::prelude::vec::Vec;
use ink::storage::Mapping;
use ink::env::Error as InkError;

#[ink::contract]
mod nft_marketplace {
    use super::*;

    #[derive(scale::Encode, scale::Decode, Clone, PartialEq, Eq, Debug)]
    #[cfg_attr(feature = "std", derive(scale_info::TypeInfo))]
    pub struct NFT {
        pub owner: AccountId,
        pub price: u128,
        pub is_for_sale: bool,
        pub token_url: String,
    }

    #[ink(storage)]
    pub struct NFTMarketplace {
        owner: AccountId,
        token_id: u64,
        nfts: Mapping<u64, NFT>,
        address_to_token_url: Mapping<(AccountId, String), bool>,
    }

    impl NFTMarketplace {
        #[ink(constructor)]
        pub fn new() -> Self {
            Self {
                owner: Self::env().caller(),
                token_id: 1,
                nfts: Default::default(),
                address_to_token_url: Default::default(),
            }
        }

        #[ink(message)]
        pub fn mint_nft(
            &mut self,
            to: AccountId,
            price: u128,
            token_url: String,
        ) -> Result<u64, InkError> {
            let caller = self.env().caller();
            assert_eq!(caller, self.owner, "Only the owner can mint NFTs");
            
            let token_key = (to, token_url.clone());
            assert!(
                !self.address_to_token_url.contains(&token_key),
                "This address has already minted this NFT"
            );

            let new_token_id = self.token_id;
            self.token_id += 1;

            let nft = NFT {
                owner: to,
                price,
                is_for_sale: false,
                token_url: token_url.clone(),
            };

            self.nfts.insert(new_token_id, &nft);
            self.address_to_token_url.insert(token_key, &true);

            Ok(new_token_id)
        }

        #[ink(message)]
        pub fn sell_nft(&mut self, token_id: u64, price: u128) {
            let caller = self.env().caller();
            let mut nft = self.nfts.get(token_id).expect("NFT does not exist");
            assert_eq!(caller, nft.owner, "Only the owner can sell the NFT");
            assert!(!nft.is_for_sale, "NFT is already for sale");

            nft.price = price;
            nft.is_for_sale = true;
            self.nfts.insert(token_id, &nft);
        }

        #[ink(message, payable)]
        pub fn buy_nft(&mut self, token_id: u64) {
            let caller = self.env().caller();
            let payment = self.env().transferred_value();

            let mut nft = self.nfts.get(token_id).expect("NFT does not exist");
            assert!(nft.is_for_sale, "NFT is not for sale");
            assert!(payment >= nft.price, "Not enough funds to buy NFT");

            let seller = nft.owner;
            nft.is_for_sale = false;
            nft.owner = caller;
            self.nfts.insert(token_id, &nft);

            // Transfer funds to the seller
            self.env().transfer(seller, payment).expect("Transfer failed");
        }

        #[ink(message)]
        pub fn get_nft_owner(&self, token_id: u64) -> AccountId {
            self.nfts.get(token_id).expect("NFT does not exist").owner
        }

        #[ink(message)]
        pub fn get_token_url(&self, token_id: u64) -> String {
            self.nfts.get(token_id).expect("NFT does not exist").token_url
        }

        #[ink(message)]
        pub fn get_available_nfts(&self) -> Vec<u64> {
            let mut available = Vec::new();
            for i in 1..self.token_id {
                if let Some(nft) = self.nfts.get(i) {
                    if nft.is_for_sale {
                        available.push(i);
                    }
                }
            }
            available
        }
    }
}
